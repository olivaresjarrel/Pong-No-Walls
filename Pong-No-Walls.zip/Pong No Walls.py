import pygame
import sys
import time
from pygame.locals import *
from pygame.math import Vector2
import random


def terminate():
    pygame.quit()
    sys.exit()


def wait_for_player_to_press_key():
    pressed = False
    while not pressed:
        for e in pygame.event.get():
            if e.type == QUIT:
                terminate()
            if e.type == KEYDOWN:
                if e.key == K_ESCAPE:
                    terminate()
                return  # start game for any other key down


def player_has_hit_baddie(player_rect, baddies):
    for b in baddies:
        if player_rect.colliderect(b['rect']):
            return True
    return False


def draw_text(text, font, surface, x, y):
    textobj = font.render(text, 1, textColor)
    textrect = textobj.get_rect()
    textrect.topleft = x, y
    surface.blit(textobj, textrect)


WINDOWWIDTH = 900
WINDOWHEIGHT = 500

DARK_GREY = Color('#404040')
WHITE = Color('#FFFFFF')
BLACK = Color('#000000')
AQUA = Color('#00FFFF')

textColor = WHITE
BACKGROUND_COLOR = BLACK
FPS = 60

PLAYER_MOVERATE = 10
BALLSPEED = random.randint(3, 5)

LEFT_KEYS = [K_LEFT, K_a]
RIGHT_KEYS = [K_RIGHT, K_d]
UP_KEYS = [K_UP, K_w]
DOWN_KEYS = [K_DOWN, K_s]


def play():
    pygame.init()
    main_clock = pygame.time.Clock()
    surf = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
    pygame.display.set_caption('Pong, No Walls')
    pygame.mouse.set_visible(False)

    font = pygame.font.Font(None, 48)

    game_over_sound = pygame.mixer.Sound('game_over.wav')
    win_sound = pygame.mixer.Sound('win.wav')
    pygame.mixer.music.load('background.mp3')
    bounceSound = pygame.mixer.Sound('blip.wav')

    playerSide_image = pygame.image.load('Side.png')
    playerSide_rect = playerSide_image.get_rect()
    playerTop_image = pygame.image.load('Top.png')
    playerTop_rect = playerTop_image.get_rect()
    playerBot_image = pygame.image.load('Top.png')
    playerBot_rect = playerBot_image.get_rect()

    computerSide_image = pygame.image.load('Side.png')
    computerSide_rect = playerSide_image.get_rect()
    computerTop_image = pygame.image.load('Top.png')
    computerTop_rect = playerTop_image.get_rect()
    computerBot_image = pygame.image.load('Top.png')
    computerBot_rect = playerBot_image.get_rect()

    surf.fill(BACKGROUND_COLOR)

    draw_text('Pong, No walls', font, surf, WINDOWWIDTH/3, WINDOWHEIGHT/3)
    draw_text('Press a key to start.', font, surf, WINDOWWIDTH/3 - 30,
              WINDOWHEIGHT/3 + 50)
    pygame.display.update()
    wait_for_player_to_press_key()

    playerWins = 0
    computerWins = 0

    play_game_again = True
    while play_game_again:
        playerSide_rect.midright = WINDOWWIDTH, WINDOWHEIGHT/2
        playerTop_rect.midtop = WINDOWWIDTH/1.3, 0
        playerBot_rect.midbottom = WINDOWWIDTH/1.3, WINDOWHEIGHT

        computerSide_rect.midleft = 0, WINDOWHEIGHT/2
        computerTop_rect.midtop = WINDOWWIDTH/4, 0
        computerBot_rect.midbottom = WINDOWWIDTH/4, WINDOWHEIGHT

        BALLSPAWNx = random.randint(350, 550)
        BALLSPAWNy = random.randint(10, WINDOWHEIGHT - 10)

        box = {'rect': pygame.Rect(BALLSPAWNx, BALLSPAWNy, 25, 25), 'color': WHITE,
               'vel': Vector2(random.randint(-2, 2), random.randint(-2, 2)) * BALLSPEED}
        # ball = {'rect': pygame.Rect(random.randint(350, 550), random.randint(10, WINDOWHEIGHT - 10),
        #                             25, 25), 'color': WHITE, 'vel': Vector2(2, -2) * BALLSPEED}

        boxes = [box]
        # ball = [ball]

        move_left = move_right = move_up = move_down = False
        pygame.mixer.music.play(-1, 0.0)

        computerWin = False
        playerWin = False
        play_game = True

        playerScore = 0
        computerScore = 0

        while play_game:

            for e in pygame.event.get():
                if e.type == QUIT:
                    terminate()

                if e.type == KEYDOWN:

                    move_left = e.key in LEFT_KEYS
                    move_right = e.key in RIGHT_KEYS
                    move_up = e.key in UP_KEYS
                    move_down = e.key in DOWN_KEYS

                if e.type == KEYUP:
                    if e.key == K_ESCAPE:
                        terminate()

                    move_left = move_left and e.key in LEFT_KEYS
                    move_right = move_right and e.key in RIGHT_KEYS
                    move_up = move_up and e.key in UP_KEYS
                    move_down = move_down and e.key in DOWN_KEYS

                if e.type == KEYDOWN:
                    if e.key == K_r:
                        box = {'rect': pygame.Rect(BALLSPAWNx, BALLSPAWNy,
                                                   25, 25), 'color': WHITE,
                               'vel': Vector2(random.randint(-2, 2), random.randint(-2, 2)) * BALLSPEED}
                        boxes = [box]

            if move_left and playerSide_rect.left >= WINDOWWIDTH/2:
                playerTop_rect.move_ip(-1 * PLAYER_MOVERATE, 0)
                playerBot_rect.move_ip(-1 * PLAYER_MOVERATE, 0)
            if move_right and playerTop_rect.right < WINDOWWIDTH:
                playerTop_rect.move_ip(PLAYER_MOVERATE, 0)
                playerBot_rect.move_ip(PLAYER_MOVERATE, 0)
            if move_up and playerSide_rect.top > 0:
                playerSide_rect.move_ip(0, -1 * PLAYER_MOVERATE)
            if move_down and playerSide_rect.bottom < WINDOWHEIGHT:
                playerSide_rect.move_ip(0, PLAYER_MOVERATE)

            if playerBot_rect.left <= WINDOWWIDTH / 2:
                move_left = False

            # Background
            surf.fill(BACKGROUND_COLOR)

            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 0), (450, 25), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 50), (450, 75), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 100), (450, 125), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 150), (450, 175), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 200), (450, 225), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 250), (450, 275), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 300), (450, 325), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 350), (450, 375), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 400), (450, 425), 2)
            pygame.draw.line(surf, AQUA, (WINDOWWIDTH / 2, 450), (450, 475), 2)

            # BALL
            for b in boxes:
                r = b['rect']
                v = b['vel']
                clr = b['color']
                r.left += v[0]
                r.top += v[1]

                # computer top
                if r.top <= 0 and r.right < WINDOWWIDTH / 2:
                    v[1] *= -1
                    playerScore += 1
                    playerScore = playerScore
                    box = {'rect': pygame.Rect(BALLSPAWNx, BALLSPAWNy, 25, 25), 'color': WHITE,
                           'vel': Vector2(random.randint(-2, 2), random.randint(-2, 2)) * BALLSPEED}
                    boxes = [box]

                # computer side
                if r.left <= 0:
                    v[0] *= -1
                    playerScore += 1
                    playerScore = playerScore
                    box = {'rect': pygame.Rect(BALLSPAWNx, BALLSPAWNy, 25, 25), 'color': WHITE,
                           'vel': Vector2(random.randint(-2, 2), random.randint(-2, 2)) * BALLSPEED}
                    boxes = [box]
                # computer bot
                if r.bottom >= WINDOWHEIGHT and r.left < WINDOWWIDTH / 2:
                    v[1] *= -1
                    playerScore += 1
                    playerScore = playerScore
                    box = {'rect': pygame.Rect(BALLSPAWNx, BALLSPAWNy, 25, 25), 'color': WHITE,
                           'vel': Vector2(random.randint(-2, 2), random.randint(-2, 2)) * BALLSPEED}
                    boxes = [box]
                # player top
                if r.top <= 0 and r.right > WINDOWWIDTH / 2:
                    v[1] *= -1
                    computerScore += 1
                    computerScore = computerScore
                    box = dict(rect=pygame.Rect(BALLSPAWNx, BALLSPAWNy, 25, 25), color=WHITE,
                               vel=Vector2(random.randint(-2, 2), random.randint(-2, 2)) * BALLSPEED)
                    boxes = [box]
                # player side
                if r.right >= WINDOWWIDTH:
                    v[0] *= -1
                    computerScore += 1
                    computerScore = computerScore
                    box = {'rect': pygame.Rect(BALLSPAWNx, BALLSPAWNy, 25, 25), 'color': WHITE,
                           'vel': Vector2(random.randint(-2, 2), random.randint(-2, 2)) * BALLSPEED}
                    boxes = [box]
                # player bot
                if r.bottom >= WINDOWHEIGHT and r.left > WINDOWWIDTH / 2:
                    v[1] *= -1
                    computerScore += 1
                    computerScore = computerScore
                    box = {'rect': pygame.Rect(BALLSPAWNx, BALLSPAWNy, 25, 25), 'color': WHITE,
                           'vel': Vector2(random.randint(-2, 2), random.randint(-2, 2)) * BALLSPEED}
                    boxes = [box]
                pygame.draw.rect(surf, clr, r)
                # pygame.draw.ellipse(surf, clr, ball)

            draw_text('Player Score: ' + str(playerScore), font, surf, WINDOWWIDTH / 1.5, 100)
            draw_text('CPU Score: ' + str(computerScore), font, surf, WINDOWWIDTH / 8, 100)

            # CPU AI
            # MAKE THE COMPUTER PADDLES FOLLOW THE BALL
            # if boxes >= WINDOWWIDTH / 2:
            #     computerTop_rect.move_ip(-1 * PLAYER_MOVERATE, 0)
            #     computerBot_rect.move_ip(-1 * PLAYER_MOVERATE, 0)
            # if move_right and playerTop_rect.right < WINDOWWIDTH:
            #     playerTop_rect.move_ip(PLAYER_MOVERATE, 0)
            #     playerBot_rect.move_ip(PLAYER_MOVERATE, 0)
            # if move_up and playerSide_rect.top > 0:
            #     playerSide_rect.move_ip(0, -1 * PLAYER_MOVERATE)
            # if move_down and playerSide_rect.bottom < WINDOWHEIGHT:
            #     playerSide_rect.move_ip(0, PLAYER_MOVERATE)

            # Blit player
            surf.blit(playerSide_image, playerSide_rect)
            surf.blit(playerTop_image, playerTop_rect)
            surf.blit(playerBot_image, playerBot_rect)

            # Blit computer
            surf.blit(computerSide_image, computerSide_rect)
            surf.blit(computerTop_image, computerTop_rect)
            surf.blit(computerBot_image, computerBot_rect)

            pygame.display.update()

            # Player collision
            if player_has_hit_baddie(playerSide_rect, boxes):
                v[0] *= -1
                bounceSound.play()
            if player_has_hit_baddie(playerTop_rect, boxes):
                v[1] *= -1
                bounceSound.play()
            if player_has_hit_baddie(playerBot_rect, boxes):
                v[1] *= -1
                bounceSound.play()
            # Computer collision
            if player_has_hit_baddie(computerSide_rect, boxes):
                v[0] *= -1
                bounceSound.play()
            if player_has_hit_baddie(computerTop_rect, boxes):
                v[1] *= -1
                bounceSound.play()
            if player_has_hit_baddie(computerBot_rect, boxes):
                v[1] *= -1
                bounceSound.play()

            if computerScore >= 11 and computerScore > playerScore + 2:
                computerScore = 0
                playerScore = 0
                computerWins += 1
                computerWins = computerWins

            if playerScore >= 11 and playerScore > computerScore + 2:
                computerScore = 0
                playerScore = 0
                playerWins += 1
                playerWins = playerWins

            if playerWins == 3:
                playerWin = True
                break

            if computerWins == 3:
                computerWin = True
                break

            main_clock.tick(FPS)     # end of main game loop

        pygame.mixer.music.stop()  # play again loop

        if computerWin:
            game_over_sound.play()
            draw_text('COMPUTER WINS', font, surf, WINDOWWIDTH/8, WINDOWHEIGHT/3)
        if playerWin:
            win_sound.play()
            draw_text('YOU WIN', font, surf, WINDOWWIDTH/1.5, WINDOWHEIGHT/3)

        computerWins = 0
        playerWins = 0

        draw_text('Press a key to play again.', font, surf, WINDOWWIDTH/3 - 80,
                  WINDOWHEIGHT/3 + 50)

        pygame.display.update()
        wait_for_player_to_press_key()

        pygame.display.update()
        main_clock.tick(40)         # end of play again loop


play()
